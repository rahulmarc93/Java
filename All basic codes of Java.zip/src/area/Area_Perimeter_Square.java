package area;

public class Area_Perimeter_Square {

		public static void main(String[] args) {
			/*
			Write a Program to Calculate Area and Perimeter of a square.


			create an Employee  class and display 5 Employee details with name,salary and age*/
			int i = 3;
			int square = i*i;
			int perimeter = 4*i;
			System.out.println("Area of i is : "+square);
			System.out.println("Perimeter of i is : "+perimeter);

		}

	}
