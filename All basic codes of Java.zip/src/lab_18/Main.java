package lab_18;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Create SessionFactory
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Employee.class)
                .buildSessionFactory();

        // Open a Session
        Session session = factory.openSession();

        try {
            // Insert Records
            session.beginTransaction();

            Employee emp1 = new Employee("Rahulkumar Saha", "Java Developer", 9000000);
            Employee emp2 = new Employee("Sakshi", "Brainless Manager", 7500000);
            Employee emp3 = new Employee("Shreya", "Manipulation Lead", 4000000);

            session.save(emp1);
            session.save(emp2);
            session.save(emp3);

            session.getTransaction().commit();

            // Retrieve Records
            session = factory.openSession();
            session.beginTransaction();

            List<Employee> employees = session.createQuery("from Employee", Employee.class).getResultList();

            for (Employee emp : employees) {
                System.out.println(emp);
            }

            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
            factory.close();
        }
    }
}