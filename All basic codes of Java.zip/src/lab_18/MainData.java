package lab_18;

public class MainData {
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager();

        // Inserting records
        manager.addEmployee("Jack", "Daniels", 50000);
        manager.addEmployee("Jameson", "Irish", 60000);

        // Retrieving and printing all records
        List<Employee> employees = manager.listEmployees();
        
        for (Employee emp : employees) {
            System.out.println("ID: " + emp.getId() + ", Name: " + emp.getFirstName() + " " + emp.getLastName() + ", Salary: " + emp.getSalary());
        }
    }
}