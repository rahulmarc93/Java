package enumDemo;

public class Days {
	
	public enum Day
	{
		MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY
	}

		public static void main(String[] args) {
		System.out.println(Day.MONDAY);

	}

}