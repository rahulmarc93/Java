package array;

public class MD_and_copy_using_user_input {

	public static void main(String[] args) {
		// create a multi-dimentional array using user input
		//create a MD array and make copy and print both original and copy array

	}

}
