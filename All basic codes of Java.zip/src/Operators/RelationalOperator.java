package Operators;

public class RelationalOperator {

	public static void main(String[] args) {
		// (==,<=,>=,!=)
		int x=10;
		int y=20;
		boolean res1=x>=y;
System.out.println(res1);

	}

}