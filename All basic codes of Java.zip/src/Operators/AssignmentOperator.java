package Operators;

public class AssignmentOperator {

	public static void main(String[] args) {
				int x=12;
				System.out.println(x);
				int y=24;
				System.out.println(y);
				y=x;
				System.out.println(y);

	}

}
