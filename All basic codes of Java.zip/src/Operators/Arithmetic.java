package Operators;

public class Arithmetic {

	public static void main(String[] args) {
			float x=4.5f;
			float y=12.4f;
			System.out.println(x+y);

	}

}
