package games_1;

public class Helloworld_$ {

	public static void main(String[] args) {
		byte num1 = 10;
		short num2 = 20;
		int num3 = 30;
		long num4 = 404040404040404040L;
		char letter = 'A';
		float num5 = 50.23F;
		double num6 = 60.86;
		boolean torf = true;
		String str = "Rahul";
		
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);
		System.out.println(letter);
		System.out.println(num5);
		System.out.println(num6);
		System.out.println(torf);
		System.out.println(str);
	}

}
