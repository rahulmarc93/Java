package lab_17;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class MainApp {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();
            
            // Create Customer
            Customer customer = new Customer();
            customer.setName("Rahulkumar Saha");
            customer.setEmail("rahulsaha@gmail.com");
            session.save(customer);

            // Create Product
            Product product = new Product();
            product.setName("Laptop");
            product.setPrice(1200.00);
            session.save(product);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
        } finally {
            session.close();
        }
        HibernateUtil.shutdown();
    }
}
