package variables;
class StaticVar
{
	//static variable
	 public static String name;
	 public static int age;
}
public class Employee {

	public static void main(String[] args) {
		StaticVar.name="Shamsheera";
		System.out.println(StaticVar.name);

	}

}