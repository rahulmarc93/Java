package variables;
		
		class EmployeeData
		{
			//Instance Var
			String name ;
			int id ;
			int age ;
			double salary ;

			public static void main(String[] args) {
				EmployeeData s1 = new EmployeeData();
				s1.name="Rahul";
				s1.id = 1;
				s1.age = 40;
				s1.salary = 85.59;
				
				EmployeeData s2 = new EmployeeData();
				s2.name="Marc" ;
				s2.id = 2 ;
				s2.age = 41 ;
				s2.salary = 12.90;
				
				EmployeeData s3 = new EmployeeData();
				s3.name="Jaadu" ;
				s3.id = 3 ;
				s3.age = 150 ;
				s3.salary = 32478768.46;
				
				EmployeeData s4 = new EmployeeData();
				s4.name="Joker" ;
				s4.id = 4 ;
				s4.age = 78 ;
				s4.salary = 768.46;
				
				EmployeeData s5 = new EmployeeData();
				s5.name="Alien" ;
				s5.id = 5 ;
				s5.age = 150 ;
				s5.salary = 8.46;
				
				EmployeeData s6 = new EmployeeData();
				s6.name="Mantis" ;
				s6.id = 6 ;
				s6.age = 150 ;
				s6.salary = 798354.46;
				
				EmployeeData s7 = new EmployeeData();
				s7.name="Snake" ;
				s7.id = 7 ;
				s7.age = 45 ;
				s7.salary = 79824.46;
				
				EmployeeData s8 = new EmployeeData();
				s8.name="Spider" ;
				s8.id = 8 ;
				s8.age = 88 ;
				s8.salary = 878345.46;
				
				EmployeeData s9 = new EmployeeData();
				s9.name="Corona" ;
				s9.id = 9 ;
				s9.age = 28 ;
				s9.salary = 32678.46;
				
				EmployeeData s10 = new EmployeeData();
				s10.name="Virus" ;
				s10.id = 10 ;
				s10.age = 58 ;
				s10.salary = 9872.46;
				
				System.out.println("Name:"+s1.name+" "+"Id:"+s1.id+" "+"Age:"+s1.age+" "+"Salary:"+s1.salary);
				System.out.println("Name:"+s2.name+" "+"Id:"+s2.id+" "+"Age:"+s2.age+" "+"Salary:"+s2.salary);
				System.out.println("Name:"+s3.name+" "+"Id:"+s3.id+" "+"Age:"+s3.age+" "+"Salary:"+s3.salary);
				System.out.println("Name:"+s4.name+" "+"Id:"+s4.id+" "+"Age:"+s4.age+" "+"Salary:"+s4.salary);
				System.out.println("Name:"+s5.name+" "+"Id:"+s5.id+" "+"Age:"+s5.age+" "+"Salary:"+s5.salary);
				System.out.println("Name:"+s6.name+" "+"Id:"+s6.id+" "+"Age:"+s6.age+" "+"Salary:"+s6.salary);
				System.out.println("Name:"+s7.name+" "+"Id:"+s7.id+" "+"Age:"+s7.age+" "+"Salary:"+s7.salary);
				System.out.println("Name:"+s8.name+" "+"Id:"+s8.id+" "+"Age:"+s8.age+" "+"Salary:"+s8.salary);
				System.out.println("Name:"+s9.name+" "+"Id:"+s9.id+" "+"Age:"+s9.age+" "+"Salary:"+s9.salary);
				System.out.println("Name:"+s10.name+" "+"Id:"+s10.id+" "+"Age:"+s10.age+" "+"Salary:"+s10.salary);
			}
		}
